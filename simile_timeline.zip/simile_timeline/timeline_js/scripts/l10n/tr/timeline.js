/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["tr"] = {
    wikiLinkLabel:  "Tartış"
};

